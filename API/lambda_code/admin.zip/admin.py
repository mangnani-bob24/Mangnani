import json

def lambda_handler(event, context):
    return {
        "statusCode": 200,
        "body": json.dumps({
            "hint": "Use your own AWS credentials to access the S3 bucket. Run the 'terraform output' command to find the target EC2 instance ID."
        })
    }
