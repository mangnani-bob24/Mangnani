import json

def lambda_handler(event, context):
    return {
        "statusCode": 200,
        "body": json.dumps({
            "hint": "The next resource is s3://sensitive-data-bucket-2024-war"
        })
    }