import json

def lambda_handler(event, context):
    path = event.get("path", "")
    if path == "/hint":
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Popular paths: /prod/home, /prod/api, /prod/public. Restricted: /prod/secure, /prod/admin."
            })
        }
    else:
        return {
            "statusCode": 404,
            "body": json.dumps({
                "error": f"The path '{path}' does not exist. Hint: Try exploring /hint."
            })
        }
