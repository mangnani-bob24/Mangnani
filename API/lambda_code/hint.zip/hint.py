import json

def lambda_handler(event, context):
    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Popular paths: /prod/home, /prod/api, /prod/public. Restricted: /prod/secure, /prod/admin."
        })
    }
